@echo off
setlocal
set GV=8.9
set BASE=%USERPROFILE%\.gradle\manual-wrapper
set HOME=%BASE%\gradle-%GV%
if not exist "%HOME%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo Downloading Gradle %GV% ...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GV%-bin.zip' -OutFile '%BASE%\gradle-%GV%-bin.zip'; Expand-Archive -Force '%BASE%\gradle-%GV%-bin.zip' '%BASE%'"
  if errorlevel 1 exit /b 1
)
call "%HOME%\bin\gradle.bat" %*
endlocal
