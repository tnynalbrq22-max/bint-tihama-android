# تطبيق بنت تهامة - مشروع Android

هذا المشروع يغلّف الموقع الحالي داخل تطبيق Android باستخدام WebView:

`https://bashrawi.com/Menu/bint_tihama_admin_preview.html`

## ما الذي يدعمه التطبيق؟
- فتح المنيو داخل التطبيق مباشرة.
- JavaScript وLocal Storage وملفات تعريف الارتباط اللازمة لعمل الموقع.
- اختيار الصور من الجهاز عند استخدام رفع الصور في لوحة الإدارة.
- فتح روابط واتساب والروابط الخارجية في التطبيقات المناسبة.
- زر الرجوع للتنقل داخل صفحات الموقع.

## إنشاء ملف APK

يلزم جهاز كمبيوتر عليه Android Studio مع تثبيت Android SDK Platform 35، واتصال إنترنت أول مرة لتنزيل Gradle ومكوّنات Android Gradle Plugin.

1. فك ضغط الملف `Bint_Tihama_Android_Project.zip`.
2. افتح نافذة Terminal أو CMD داخل مجلد المشروع وشغّل أمر تهيئة Gradle Wrapper مرة واحدة:
   - Windows: `gradlew.bat wrapper --gradle-version 8.9`
   - macOS/Linux: `./gradlew wrapper --gradle-version 8.9`
   (سيتم تنزيل Gradle أول مرة، ثم إنشاء ملفات Gradle Wrapper القياسية).
3. افتح مجلد المشروع في Android Studio وانتظر اكتمال Gradle Sync. إذا طلب Android Studio تنزيل SDK 35 وافق على ذلك.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. بعد نجاح البناء ستجد الملف عادةً في:
   `app/build/outputs/apk/debug/app-debug.apk`

ويمكن البناء من الطرفية بعد إعداد Android SDK:
- Windows: `gradlew.bat assembleDebug`
- macOS/Linux: `./gradlew assembleDebug`

## تنبيهات مهمة قبل النشر
- هذا تطبيق WebView متصل بالموقع؛ يحتاج إلى الإنترنت، وأي تحديث للموقع يظهر في التطبيق دون إعادة بناء APK.
- راجعت صفحة الموقع المنشورة، وهي تعرض نفسها كنسخة معاينة وتوضح أن تغييرات لوحة الإدارة تُحفظ في المتصفح نفسه فقط، كما تحذر من أن كلمة المرور موجودة داخل ملف HTML. تحويل الصفحة إلى APK لا يعالج هاتين النقطتين ولا يجعل تسجيل دخول الأدمن آمنًا أو يجعل التعديلات مشتركة بين الأجهزة.
- قبل توزيع التطبيق على العملاء، ينبغي نقل دخول الإدارة إلى مصادقة آمنة على الخادم وربط التعديلات بقاعدة البيانات مع صلاحيات مناسبة.
